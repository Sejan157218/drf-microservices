
from django.contrib import admin
from django.urls import path
from products.views import AllProduct

urlpatterns = [
    path('admin/', admin.site.urls),
    path('products/', AllProduct.as_view()),

]
