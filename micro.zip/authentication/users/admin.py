from django.contrib import admin
from .models import UserList

admin.site.register(UserList)
# Register your models here.
